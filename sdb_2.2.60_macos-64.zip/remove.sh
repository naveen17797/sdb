#!/bin/bash -ex
SDB_PATH=tools/sdb
BASH_RC=~/.profile

if [ -f "${INSTALLED_PATH}/${SDB_PATH}" ]; then
    "${INSTALLED_PATH}/${SDB_PATH}" kill-server
fi

rm -rf "${INSTALLED_PATH}/${SDB_PATH}"
rm -rf ~/.sdb
if [ -f ${BASH_RC} ]; then
    sed -i -E '/# Enable programmable sdb completion features/,/fi/d' ${BASH_RC}
fi

exit 0
